abstract class IGetUserAddressApiService {
  
  Future<Map<String, dynamic>> getUserAddress(int id);
}