import 'package:flutter/material.dart';
import 'package:flutter_riverpod/legacy.dart';


final dateRangeProvider =
    StateProvider.autoDispose<DateTimeRange?>((ref) => null);