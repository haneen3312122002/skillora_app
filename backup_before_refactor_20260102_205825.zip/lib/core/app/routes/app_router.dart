import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:notes_tasks/core/app/routes/app_routes.dart';
import 'package:notes_tasks/core/app/layouts/app_layouts.dart';
import 'package:notes_tasks/core/app/routes/routes_helpers.dart';
import 'package:notes_tasks/core/services/auth/providers/auth_state_provider.dart';
import 'package:notes_tasks/core/services/auth/providers/user_role_provider.dart';
import 'package:notes_tasks/core/shared/enums/role.dart';
import 'package:notes_tasks/core/shared/widgets/common/loading_indicator.dart';

// Auth screens
import 'package:notes_tasks/modules/auth/presentation/screens/login_screen.dart';
import 'package:notes_tasks/modules/auth/presentation/screens/email_verfication.dart';
import 'package:notes_tasks/modules/auth/presentation/screens/register.dart';
import 'package:notes_tasks/modules/auth/presentation/screens/reset_password.dart';

// Chat
import 'package:notes_tasks/modules/chat/presentation/screens/chat_details_page.dart';
import 'package:notes_tasks/modules/chat/presentation/screens/chats_list_page.dart';

// Home + categories
import 'package:notes_tasks/modules/home/presentation/screens/home_screen.dart';
import 'package:notes_tasks/modules/home/presentation/screens/jobs_by_category_page.dart';

// Job details
import 'package:notes_tasks/modules/job/presentation/widgets/job_details_page.dart';

// Notifications
import 'package:notes_tasks/modules/notifications/presentation/screens/notifications_page.dart';

// Profile + project details
import 'package:notes_tasks/modules/profile/presentation/screens/profile_screen.dart';
import 'package:notes_tasks/modules/profile/presentation/widgets/project/project_detail_page.dart';

// Proposals
import 'package:notes_tasks/modules/propsal/presentation/screens/client/client_job_proposals_section.dart';
import 'package:notes_tasks/modules/propsal/presentation/screens/client/client_proposals_page.dart';
import 'package:notes_tasks/modules/propsal/presentation/screens/freelancer/freelancer_proposals_section.dart';
import 'package:notes_tasks/modules/propsal/presentation/screens/proposal_details_page.dart';

// Settings
import 'package:notes_tasks/modules/settings/presentation/screens/change_password_screen.dart';
import 'package:notes_tasks/modules/settings/presentation/screens/settings_screen.dart';

// Users
import 'package:notes_tasks/modules/users/presentation/features/user_details/screens/user_section_details_view.dart';
import 'package:notes_tasks/modules/users/presentation/features/user_details/user_section_details_args.dart';

// ✅ Helpers live in a separate file, but still part of the same library.

final goRouterProvider = Provider<GoRouter>((ref) {
  final authAsync = ref.watch(authStateProvider);
  final roleAsync = ref.watch(userRoleProvider);

  return GoRouter(
    initialLocation: AppRoutes.loading,
    routes: [
      GoRoute(
        path: AppRoutes.loading,
        builder: (_, __) => const LoadingIndicator(withBackground: true),
      ),

      // Auth
      GoRoute(path: AppRoutes.login, builder: (_, __) => const LoginScreen()),
      GoRoute(
          path: AppRoutes.register, builder: (_, __) => const RegisterScreen()),
      GoRoute(
          path: AppRoutes.resetPassword,
          builder: (_, __) => const ResetPasswordScreen()),
      GoRoute(
          path: AppRoutes.verifyEmail,
          builder: (_, __) => const VerifyEmailScreen()),

      // Settings (outside shell)
      GoRoute(
          path: AppRoutes.settings,
          name: 'settings',
          builder: (_, __) => const SettingsScreen()),
      GoRoute(
          path: AppRoutes.changePassword,
          builder: (_, __) => const ChangePasswordScreen()),

      // Shared / details
      GoRoute(
        path: AppRoutes.jobsByCategory,
        builder: (context, state) {
          final args = state.extra as JobsByCategoryArgs;
          return JobsByCategoryPage(
              category: args.category, titleLabel: args.titleLabel);
        },
      ),
      GoRoute(
        path: AppRoutes.jobDetails,
        builder: (context, state) {
          final args = state.extra as JobDetailsArgs;
          return JobDetailsPage(mode: args.mode, jobId: args.jobId);
        },
      ),
      GoRoute(
        path: AppRoutes.projectDetails,
        name: AppRoutes.projectDetails,
        builder: (context, state) {
          final args = state.extra as ProjectDetailsArgs;
          return ProjectDetailsPage(project: args.project, mode: args.mode);
        },
      ),
      GoRoute(
        path: AppRoutes.clientProposals,
        builder: (context, state) {
          final args = state.extra as ClientProposalsArgs;
          return ClientJobProposalsPage(jobId: args.jobId);
        },
      ),
      GoRoute(
        path: AppRoutes.proposalDetails,
        builder: (context, state) {
          final args = state.extra as ProposalDetailsArgs;
          return ProposalDetailsPage(
              proposalId: args.proposalId, mode: args.mode);
        },
      ),
      GoRoute(
        path: AppRoutes.userSectionDetails,
        builder: (_, state) {
          final args = state.extra as UserSectionDetailsArgs;
          return UserSectionDetailsView(
              title: args.title, provider: args.provider, mapper: args.mapper);
        },
      ),

      // Chat details
      GoRoute(
        path: '${AppRoutes.chatDetails}/:id',
        builder: (context, state) {
          final chatId = state.pathParameters['id']!;
          return ChatDetailsScreen(chatId: chatId);
        },
      ),

      // Shells
      ShellRoute(
        builder: (_, __, child) => ClientShell(child: child),
        routes: [
          GoRoute(
              path: AppRoutes.clientHome, builder: (_, __) => const HomePage()),
          GoRoute(
              path: AppRoutes.clientNotifications,
              builder: (_, __) => const NotificationsPage()),
          GoRoute(
              path: AppRoutes.clientChats,
              builder: (_, __) => const ChatsListScreen()),
          GoRoute(
              path: AppRoutes.clientProfile,
              builder: (_, __) => const ProfileScreen()),
        ],
      ),
      ShellRoute(
        builder: (_, __, child) => FreelancerShell(child: child),
        routes: [
          GoRoute(
              path: AppRoutes.freelanceHome,
              builder: (_, __) => const HomePage()),
          GoRoute(
              path: AppRoutes.freelancerNotifications,
              builder: (_, __) => const NotificationsPage()),
          GoRoute(
              path: AppRoutes.freelancerProposals,
              builder: (_, __) => const FreelancerProposalsListPage()),
          GoRoute(
              path: AppRoutes.freelancerChats,
              builder: (_, __) => const ChatsListScreen()),
          GoRoute(
              path: AppRoutes.freelancerProfile,
              builder: (_, __) => const ProfileScreen()),
        ],
      ),
    ],
    redirect: (context, state) {
      final loc = state.uri.path;

      // If user is intentionally switching accounts, let them stay on login.
      if (isSwitchLogin(state)) return null;

      // 1) Auth is still loading -> show loading screen.
      if (authAsync.isLoading) {
        return isLoadingRoute(loc) ? null : AppRoutes.loading;
      }
      if (authAsync.hasError) return AppRoutes.login;

      final user = authAsync.value;

      // 2) Not logged in -> allow only auth routes + reset password.
      if (user == null) {
        final canStay = isAuthRoute(loc) || isResetPasswordRoute(loc);
        return canStay ? null : AppRoutes.login;
      }

      // 3) Email not verified -> force verify screen.
      if (!user.emailVerified && !isVerifyEmailRoute(loc)) {
        return AppRoutes.verifyEmail;
      }

      // 4) Role still loading -> keep showing loading.
      if (roleAsync.isLoading) {
        return isLoadingRoute(loc) ? null : AppRoutes.loading;
      }
      if (roleAsync.hasError) return AppRoutes.login;

      final role = roleAsync.value ?? UserRole.client;

      // 5) If we are on verify screen but user is verified now -> go home.
      if (user.emailVerified && isVerifyEmailRoute(loc)) {
        return homeForRole(role);
      }

      // 6) Logged-in user should not hang around on auth/loading/root.
      final shouldKickToHome = (isAuthRoute(loc) && !isSwitchLogin(state)) ||
          isLoadingRoute(loc) ||
          (loc == '/' && !isResetPasswordRoute(loc));

      if (shouldKickToHome) {
        return homeForRole(role);
      }

      // 7) Shell protection per role (details pages are allowed outside the shell).
      if (!allowOutsideShell(loc)) {
        final okForRole = isRoleShellPath(role, loc);
        if (!okForRole) return homeForRole(role);
      }

      return null;
    },
  );
});
