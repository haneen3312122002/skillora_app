import 'package:flutter_riverpod/legacy.dart';
import 'package:notes_tasks/core/shared/enums/role.dart';

final selectedRoleProvider = StateProvider<UserRole?>((ref) => null);
