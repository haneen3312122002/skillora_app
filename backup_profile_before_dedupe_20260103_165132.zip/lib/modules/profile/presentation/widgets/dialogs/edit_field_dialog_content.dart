// TODO: move EditFieldDialogContent here
