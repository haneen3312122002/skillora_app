import 'package:flutter_riverpod/legacy.dart';

final bioEditingProvider = StateProvider<bool>((ref) => false);