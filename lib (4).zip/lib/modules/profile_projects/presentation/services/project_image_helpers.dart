// TODO: move pickAndUploadProjectCover here
