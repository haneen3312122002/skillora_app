class AppFonts {

  static const String primaryFont = 'Poppins';


  static const String secondaryFont = 'Roboto';
}