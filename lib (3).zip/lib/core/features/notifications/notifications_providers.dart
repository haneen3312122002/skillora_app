import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'notifications_service.dart';

final notificationsServiceProvider = Provider<NotificationsService>((ref) {
  return NotificationsService(
    messaging: FirebaseMessaging.instance,
    db: FirebaseFirestore.instance,
    local: FlutterLocalNotificationsPlugin(),
  );
});

final notificationsBootstrapProvider = Provider<NotificationsBootstrap>((ref) {
  return NotificationsBootstrap(ref);
});

class NotificationsBootstrap {
  NotificationsBootstrap(this.ref);
  final Ref ref;

  bool _didInit = false;

  Future<void> init({
    required String uid,
    required bool isFreelancer,
  }) async {
    if (_didInit) return;
    _didInit = true;

    await ref.read(notificationsServiceProvider).initForUser(
          uid: uid,
          isFreelancer: isFreelancer,
        );
  }
}
