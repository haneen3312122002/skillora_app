abstract class IGetBasicUsersApiService {
  Future<List<Map<String, dynamic>>> getBasicUsers();
}