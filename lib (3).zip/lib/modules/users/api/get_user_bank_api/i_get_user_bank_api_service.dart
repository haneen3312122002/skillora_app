abstract class IGetUserBankApiService {
  
  Future<Map<String, dynamic>> getUserBank(int id);
}